import '../notifiche/data/source/notifiche_source.dart';
import 'source/notifiche_source.dart';

abstract class NotificheRepository {
  Future<List<dynamic>> tutti(); // Sostituisci dynamic con il tuo modello Promemoria se necessario
  Future<void> alle(int ora, int minuto, String titolo);
  Future<void> traSecondi(int secondi, String titolo);
  Future<void> elimina(int id);
  Future<void> segnaFatto(int id);
  Future<bool> permessoConcesso();
  Future<bool> chiediPermesso();
}

class NotificheRepositoryImpl implements NotificheRepository {
  final NotificheSource _notificheSource;

  NotificheRepositoryImpl(this._notificheSource, dynamic promemoriaStore);

  @override
  Future<List<dynamic>> tutti() async {
    return [];
  }

  @override
  Future<void> alle(int ora, int minuto, String titolo) async {
  }

  @override
  Future<void> traSecondi(int secondi, String titolo) async {
  }

  @override
  Future<void> elimina(int id) async {
    await _notificheSource.cancella(id);
  }

  @override
  Future<void> segnaFatto(int id) async {
    await _notificheSource.cancella(id);
  }

  @override
  Future<bool> permessoConcesso() {
    return _notificheSource.permessoConcesso();
  }

  @override
  Future<bool> chiediPermesso() {
    return _notificheSource.chiediPermesso();
  }
}
import 'package:promemoria/notifiche/domain/promemoria.dart';

import '../domain/promemoria.dart';

abstract class PromemoriaStore {
  Future<List<Promemoria>> tutti();
  Future<void> aggiungi(Promemoria promemoria);
  Future<void> elimina(int id);
  Future<void> segnaFatto(int id);

  Future<void> salva(Promemoria p) async {}
}

class PromemoriaStoreMemoria implements PromemoriaStore {
  final List<Promemoria> _lista = [];

  @override
  Future<List<Promemoria>> tutti() async => _lista;

  @override
  Future<void> aggiungi(Promemoria promemoria) async {
    _lista.add(promemoria);
  }

  @override
  Future<void> elimina(int id) async {
    _lista.removeWhere((p) => p.id == id);
  }

  @override
  Future<void> segnaFatto(int id) async {
    final index = _lista.indexWhere((p) => p.id == id);
    if (index != -1) {
      final p = _lista[index];
      _lista[index] = p.copyWith(completato: true); 
    }
  }
}



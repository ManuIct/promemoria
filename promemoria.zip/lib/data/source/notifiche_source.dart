import 'package:promemoria/notifiche/data/source/notifiche_source.dart' hide NotificheSource;

import 'source/notifiche_source.dart';

class NotificheRepository {
  final NotificheSource _notificheSource;

  NotificheRepository({required NotificheSource NotificheSource})
        : _notificheSource = NotificheSource;

  Future<void> inizializza({void Function(String? payload)? onTap}) {
    return _notificheSource.inizializza(onTap: onTap);
  }

  Future<bool> permessoConcessi() {
    return _notificheSource.permessoConcesso();
  }

  Future<bool> richiediPermessi() {
    return _notificheSource.chiediPermesso();
  }

  Future<void> programmaPromemoria({
    required int id,
    required DateTime quando,
    required String titolo,
  }) async {
    await _notificheSource.programma(
      id: id,
      quando: quando,
      titolo: titolo
      );
  }

  Future<void> cancellaPromemoria(int id) {
    return _notificheSource.cancella(id);
  }

  Future<List<int>> ottieniIdInCoda() {
    return _notificheSource.idInCoda();
  }

  Future<Object?> chiediPermesso() async {}
}
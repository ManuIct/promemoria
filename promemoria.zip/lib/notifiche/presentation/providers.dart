import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

class NotificheRepository {
  Future<bool> permessoConcesso() async => true;
  Future<bool> chiediPermesso() async => true;
  
  Future<void> alle(int ora, int minuto, String titolo) async {
    print("Notifica salvata per le $ora:$minuto - $titolo");
  }
  
  Future<void> traSecondi(int secondi, String titolo) async {
    print("Notifica salvata tra $secondi secondi - $titolo");
  }
}

final NotificheRepositoryProvider = Provider<NotificheRepository>((ref) {
  return NotificheRepository();
});

class PermessoController extends AsyncNotifier<bool> {
  NotificheRepository get _repo => ref.read(NotificheRepositoryProvider);

  @override
  Future<bool> build() => _repo.permessoConcesso();

  Future<bool> chiedi() async {
    final concesso = await _repo.chiediPermesso();
    state = AsyncData(concesso);
    return concesso;
  }

  Future<void> ricontrolla() async {
    state = AsyncData(await _repo.permessoConcesso());
  }
}

final permessoProvider =
    AsyncNotifierProvider<PermessoController, bool>(PermessoController.new);

class PromemoriaNotifier extends StateNotifier<List<dynamic>> {
  PromemoriaNotifier(this.ref) : super([]);

  final Ref ref;

  NotificheRepository get _repo => ref.read(NotificheRepositoryProvider);

  Future<bool> aggiungi(String titolo, int ora, int minuto) async {
    final concesso = await ref.read(permessoProvider.notifier).chiedi();
    

    await _repo.alle(ora, minuto, titolo);
    

    await _ricaricaLista();
    return concesso;
  }

  Future<bool> aggiungiTraSecondi(String titolo, int secondi) async {
    final concesso = await ref.read(permessoProvider.notifier).chiedi();
    await _repo.traSecondi(secondi, titolo);
    await _ricaricaLista();
    return concesso;
  }

  Future<void> _ricaricaLista() async {

  }
}


final promemoriaProvider = 
    StateNotifierProvider<PromemoriaNotifier, List<dynamic>>((ref) {
  return PromemoriaNotifier(ref);
});
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
// ASSICURATI CHE QUESTO IMPORT PUNTI AL FILE DOVE C'È promemoriaProvider
import '../providers.dart'; 

String quandoInTesto(DateTime data) {
  final giorni = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
  final mesi = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];

  final giornoSettimana = giorni[data.weekday - 1];
  final mese = mesi[data.month - 1];
  final oraString = data.hour.toString().padLeft(2, '0');
  final minutoString = data.minute.toString().padLeft(2, '0');

  return '$giornoSettimana ${data.day} $mese alle $oraString:$minutoString';
}

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  Future<void> _aggiungi(
    BuildContext context,
    WidgetRef ref,
    Future<bool> Function() azione,
  ) async {
    final messenger = ScaffoldMessenger.of(context);
    final concesso = await azione();

    if (!concesso) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Notifiche non permesse: il promemoria è salvato ma non suonerà'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('I miei promemoria')),
      body: const Center(child: Text('Qui appariranno i promemoria')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'prova',
            tooltip: 'Fra 10 secondi',
            onPressed: () => _aggiungi(
              context,
              ref,
              // La sintassi ora è corretta
              () => ref
                  .read(promemoriaProvider.notifier)
                  .aggiungiTraSecondi('Fra 10 secondi', 10),
            ),
            child: const Icon(Icons.timer_10),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'nuovo',
            onPressed: () => context.push('/nuovo'),
            icon: const Icon(Icons.add_alarm),
            label: const Text('Nuovo'),
          ),
        ],
      ),
    );
  }
}
import 'package:timezone/timezone.dart' as tz;

tz.TZDateTime inFuso(DateTime quando, tz.Location luogo) => tz.TZDateTime(
      luogo,
      quando.year,
      quando.month,
      quando.day,
      quando.hour,
      quando.minute,
      quando.second,
);